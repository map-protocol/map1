"""Allow `python -m map1` to invoke the CLI."""
from map1._cli import main

main()
